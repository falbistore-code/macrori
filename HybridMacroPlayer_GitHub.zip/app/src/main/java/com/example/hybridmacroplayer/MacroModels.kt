
package com.example.hybridmacroplayer

import org.json.JSONArray
import org.json.JSONObject

data class MacroStep(
    val action: String,
    val x: Int? = null,
    val y: Int? = null,
    val x2: Int? = null,
    val y2: Int? = null,
    val duration: Long? = null,
    val delayAfter: Long = 300L
)

data class Macro(
    val id: String,
    val name: String,
    val steps: List<MacroStep>
)

object MacroParser {

    fun parseSingleMacro(json: String): Macro? {
        return try {
            val obj = JSONObject(json)
            parseMacroObject(obj)
        } catch (e: Exception) {
            null
        }
    }

    fun parseMacroArray(arr: JSONArray): List<Macro> {
        val list = mutableListOf<Macro>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val macro = parseMacroObject(obj)
            if (macro != null) list.add(macro)
        }
        return list
    }

    private fun parseMacroObject(obj: JSONObject): Macro? {
        val id = obj.optString("id", System.currentTimeMillis().toString())
        val name = obj.optString("name", "Macro-$id")
        val stepsArr = obj.optJSONArray("steps") ?: return null
        val steps = mutableListOf<MacroStep>()
        for (i in 0 until stepsArr.length()) {
            val s = stepsArr.optJSONObject(i) ?: continue
            val action = s.optString("action", "")
            if (action.isEmpty()) continue
            val step = MacroStep(
                action = action,
                x = if (s.has("x")) s.optInt("x") else null,
                y = if (s.has("y")) s.optInt("y") else null,
                x2 = if (s.has("x2")) s.optInt("x2") else null,
                y2 = if (s.has("y2")) s.optInt("y2") else null,
                duration = if (s.has("duration")) s.optLong("duration") else null,
                delayAfter = if (s.has("delayAfter")) s.optLong("delayAfter") else 300L
            )
            steps.add(step)
        }
        if (steps.isEmpty()) return null
        return Macro(id, name, steps)
    }

    fun toJson(macro: Macro): String {
        val obj = JSONObject()
        obj.put("id", macro.id)
        obj.put("name", macro.name)
        val arr = JSONArray()
        macro.steps.forEach { step ->
            val s = JSONObject()
            s.put("action", step.action)
            step.x?.let { s.put("x", it) }
            step.y?.let { s.put("y", it) }
            s.put("delayAfter", step.delayAfter)
            step.x2?.let { s.put("x2", it) }
            step.y2?.let { s.put("y2", it) }
            step.duration?.let { s.put("duration", it) }
            arr.put(s)
        }
        obj.put("steps", arr)
        return obj.toString()
    }
}
