
package com.example.hybridmacroplayer

import android.content.Context
import android.content.Intent
import android.widget.Toast

object MacroRunner {

    @Volatile
    var currentMacro: Macro? = null

    fun startMacro(context: Context, macro: Macro) {
        currentMacro = macro
        Toast.makeText(context, "Macro '${macro.name}' akan dijalankan. Pindah ke aplikasi target dalam 3 detik.", Toast.LENGTH_LONG).show()
        val intent = Intent(context, MacroAccessibilityService::class.java)
        intent.putExtra("start_macro", true)
        context.startService(intent)
    }
}
