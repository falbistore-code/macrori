
package com.example.hybridmacroplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // tidak dipakai
    }

    override fun onInterrupt() {
        handler.removeCallbacksAndMessages(null)
    }

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        val start = intent?.getBooleanExtra("start_macro", false) ?: false
        if (start) startRunningMacro()
        return super.onStartCommand(intent, flags, startId)
    }

    private fun startRunningMacro() {
        val macro = MacroRunner.currentMacro ?: return
        handler.postDelayed({ runStep(macro, 0) }, 3000L)
    }

    private fun runStep(macro: Macro, index: Int) {
        if (index >= macro.steps.size) return
        val step = macro.steps[index]
        when (step.action) {
            "tap" -> doTap(step) { scheduleNext(macro, index, step.delayAfter) }
            "swipe" -> doSwipe(step) { scheduleNext(macro, index, step.delayAfter) }
            "wait" -> scheduleNext(macro, index, step.duration ?: step.delayAfter)
            else -> scheduleNext(macro, index, step.delayAfter)
        }
    }

    private fun scheduleNext(macro: Macro, index: Int, delay: Long) {
        handler.postDelayed({ runStep(macro, index + 1) }, delay)
    }

    private fun doTap(step: MacroStep, done: () -> Unit) {
        val x = step.x ?: return done()
        val y = step.y ?: return done()
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val dur = step.duration ?: 50L
        val stroke = GestureDescription.StrokeDescription(path, 0, dur)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, null)
    }

    private fun doSwipe(step: MacroStep, done: () -> Unit) {
        val x1 = step.x ?: return done()
        val y1 = step.y ?: return done()
        val x2 = step.x2 ?: return done()
        val y2 = step.y2 ?: return done()
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val dur = step.duration ?: 300L
        val stroke = GestureDescription.StrokeDescription(path, 0, dur)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, null)
    }
}
