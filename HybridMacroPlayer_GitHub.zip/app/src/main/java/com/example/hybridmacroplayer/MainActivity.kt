
package com.example.hybridmacroplayer

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.io.BufferedReader

class MainActivity : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtLog: TextView
    private lateinit var listBuiltIn: ListView
    private lateinit var listImported: ListView

    private val builtInMacros = mutableListOf<Macro>()
    private val importedMacros = mutableListOf<Macro>()

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data?.data != null) {
            val uri = result.data!!.data!!
            importMacroFromUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtStatus)
        txtLog = findViewById(R.id.txtLog)
        listBuiltIn = findViewById(R.id.listBuiltIn)
        listImported = findViewById(R.id.listImported)

        findViewById<Button>(R.id.btnEnableService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnImportMacro).setOnClickListener {
            openFilePicker()
        }

        loadBuiltInMacros()
        loadImportedMacros()
        updateAccessibilityStatus()
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
    }

    private fun log(msg: String) {
        txtLog.append("\n$msg")
    }

    private fun updateAccessibilityStatus() {
        val enabled = isAccessibilityEnabled(this)
        txtStatus.text = if (enabled) {
            "Accessibility: AKTIF (siap menjalankan macro)"
        } else {
            "Accessibility: NON-AKTIF (aktifkan dulu di pengaturan)"
        }
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return list.any { it.resolveInfo.serviceInfo.packageName == context.packageName }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        importLauncher.launch(intent)
    }

    private fun importMacroFromUri(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val text = input.bufferedReader().use(BufferedReader::readText)
            val macro = MacroParser.parseSingleMacro(text)
            if (macro != null) {
                MacroStorage.saveImportedMacro(this, macro)
                Toast.makeText(this, "Macro '${macro.name}' diimport.", Toast.LENGTH_SHORT).show()
                log("Import macro: ${macro.name}")
                loadImportedMacros()
            } else {
                Toast.makeText(this, "Format macro tidak valid.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal import: ${e.message}", Toast.LENGTH_SHORT).show()
            log("Error import: ${e.message}")
        }
    }

    private fun loadBuiltInMacros() {
        builtInMacros.clear()
        try {
            val input = assets.open("internal_macros.json")
            val text = input.bufferedReader().use(BufferedReader::readText)
            val arr = JSONArray(text)
            builtInMacros.addAll(MacroParser.parseMacroArray(arr))
        } catch (e: Exception) {
            log("Gagal load built-in: ${e.message}")
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            builtInMacros.map { it.name })
        listBuiltIn.adapter = adapter
        listBuiltIn.setOnItemClickListener { _, _, position, _ ->
            val macro = builtInMacros[position]
            MacroRunner.startMacro(this, macro)
            log("Jalankan built-in: ${macro.name}")
        }
    }

    private fun loadImportedMacros() {
        importedMacros.clear()
        importedMacros.addAll(MacroStorage.loadImportedMacros(this))
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            importedMacros.map { it.name })
        listImported.adapter = adapter
        listImported.setOnItemClickListener { _, _, position, _ ->
            val macro = importedMacros[position]
            MacroRunner.startMacro(this, macro)
            log("Jalankan import: ${macro.name}")
        }
    }
}
