
package com.example.hybridmacroplayer

import android.content.Context
import org.json.JSONArray
import java.io.File

object MacroStorage {

    private const val IMPORTED_FILE = "imported_macros.json"

    fun saveImportedMacro(context: Context, macro: Macro) {
        val list = loadImportedMacros(context).toMutableList()
        val idx = list.indexOfFirst { it.id == macro.id }
        if (idx >= 0) list[idx] = macro else list.add(macro)
        saveList(context, list)
    }

    fun loadImportedMacros(context: Context): List<Macro> {
        return try {
            val file = File(context.filesDir, IMPORTED_FILE)
            if (!file.exists()) return emptyList()
            val text = file.readText()
            val arr = JSONArray(text)
            MacroParser.parseMacroArray(arr)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveList(context: Context, list: List<Macro>) {
        val arr = JSONArray()
        list.forEach { macro ->
            val json = MacroParser.toJson(macro)
            arr.put(org.json.JSONObject(json))
        }
        val file = File(context.filesDir, IMPORTED_FILE)
        file.writeText(arr.toString())
    }
}
